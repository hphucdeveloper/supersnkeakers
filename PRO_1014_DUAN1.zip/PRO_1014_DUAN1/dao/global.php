<?php
    //khai báo đường dẫn
    define("IMG_PATH_ADMIN","../uploads/");
    define("IMG_PATH","uploads/");
?>